import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class MainMenu extends JFrame{

    private JPanel panelMenu;
    private JButton playButton;
    private JButton settingsButton;
    private JButton highscoreButton;

    public MainMenu() {
        JFrame frame = new JFrame("MainMenu");
        frame.setContentPane(panelMenu);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);

        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);

        highscoreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });

        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    settingsMenuGUI sm = new settingsMenuGUI();
                    frame.dispose();

                }
                catch (Exception ex){

                }
            }
        });
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Tetris tetrs = new Tetris();
                    frame.dispose();

                }
                catch (Exception ex){

                }
            }
        });
    }



}

