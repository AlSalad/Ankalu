
public class start {
    public static void main(String[] args) {
        MainMenu mM = new MainMenu();
    }
}
