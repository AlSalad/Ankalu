import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class musicGUI {

    private JPanel musicPanel;
    private JButton selectMusic;
    private JList musicList;

    public musicGUI(){
        JFrame frame = new JFrame("musicGUI");
        frame.setContentPane(musicPanel);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setVisible(true);


//        musicList.addListSelectionListener(new ListSelectionListener() {
//
//            @Override
//            public void valueChanged(ListSelectionEvent arg0) {
//                if (!arg0.getValueIsAdjusting()) {
//                    label.setText(dataList.getSelectedValue().toString());
//                }
//            }
//        });



    }

}

